package model;

/**
 * Eine spezielle Spy-Unterklasse für einen Street Samurai.
 * Der Street Samurai startet mit 40 Lebenspunkten und erhält zufällige Angriffspunkte.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class StreetSamurai extends Spy {

    /**
     * Erstellt einen Street Samurai mit vorgegebenem Namen und Beschreibung.
     * Die Lebenspunkte werden auf 40 gesetzt und die Angriffspunkte zufällig erhöht.
     *
     * @param name der Name des Street Samurai
     * @param description die Beschreibung des Street Samurai
     */
    public StreetSamurai(String name, String description) {
        super(name, description);
        this.setHealthPoints(40);
        this.setMaxHealthPoints(this.getHealthPoints());
        int bonusAttack = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 11);
        this.setAttackPoints(5 + bonusAttack);
    }
}