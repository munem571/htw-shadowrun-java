package model;

/**
 * Ein spezieller Gegner (Driver), der von Villain erbt.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Driver extends Villain {

    private boolean getawayVehicle = true;

    /**
     * Erstellt einen Driver mit Name, Beschreibung, Lebenspunkten und Angriffspunkten.
     *
     * @param name der Name des Drivers
     * @param description die Beschreibung des Drivers
     * @param healthPoints die Lebenspunkte des Drivers
     * @param attackPoints die Angriffspunkte des Drivers
     */
    public Driver(String name, String description, int healthPoints, int attackPoints) {
        super(name, description, healthPoints, attackPoints);
    }

    /**
     * Gibt an, ob der Driver ein Fluchtfahrzeug besitzt.
     *
     * @return true, wenn ein Fluchtfahrzeug verfügbar ist
     */
    public boolean hasGetawayVehicle() {
        return this.getawayVehicle;
    }
}
