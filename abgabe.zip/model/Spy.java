package model;

/**
 * Basisklasse für alle Spiontypen, die dem Team beitreten können.
 *
 * Definiert gemeinsame Eigenschaften und Verhalten von Charakteren.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public abstract class Spy {

    private String name;
    private String description;
    private int healthPoints;
    private int maxHealthPoints;
    private int attackPoints = 5;
    private int charismaPoints = 3;
    private int cyberExperiencePoints = 4;
    private int arcanePoints = 0;
    private boolean alive = true;

    /**
     * Erstellt einen Spion mit Name und Beschreibung.
     *
     * @param name der Name des Spions
     * @param description die Beschreibung des Spions
     */
    public Spy(String name, String description) {
        this.name = name;
        this.description = description;
        this.healthPoints = 50;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public int getMaxHealthPoints() {
        return maxHealthPoints;
    }

    protected void setMaxHealthPoints(int maxHealthPoints) {
        this.maxHealthPoints = maxHealthPoints;
    }

    public int getAttackPoints() {
        return attackPoints;
    }

    public void setAttackPoints(int attackPoints) {
        this.attackPoints = attackPoints;
    }

    public int getCharismaPoints() {
        return charismaPoints;
    }

    public void setCharismaPoints(int charismaPoints) {
        this.charismaPoints = charismaPoints;
    }

    public int getCyberExperiencePoints() {
        return cyberExperiencePoints;
    }

    public void setCyberExperiencePoints(int cyberExperiencePoints) {
        this.cyberExperiencePoints = cyberExperiencePoints;
    }

    public int getArcanePoints() {
        return arcanePoints;
    }

    public void setArcanePoints(int arcanePoints) {
        this.arcanePoints = arcanePoints;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    /**
     * Fügt dem Spion Schaden zu und prüft, ob er ausgeschaltet wird.
     *
     * @param amount die Schadensmenge
     */
    public void takeDamage(int amount) {
        if (amount > 0) {
            this.healthPoints -= amount;
            if (this.healthPoints <= 0) {
                this.healthPoints = 0;
                this.alive = false;
            }
        }
    }

    /**
     * Berechnet den Angriffsschaden des Spions mit Zufallsfaktor.
     *
     * @return der verursachte Schaden
     */
    public int attack() {
        int baseDamage = (int) (this.attackPoints * 2.3 + 1);
        java.util.Random rnd = new java.util.Random();
        int roll = rnd.nextInt(100); // 0-99
        if (roll < 13) { // 13% fail (0-12)
            return 0;
        } else if (roll < 25) { // next 12% (13-24)
            return baseDamage * 2;
        } else { // remaining 75%
            return baseDamage;
        }
    }

    /**
     * Führt einen Verhandlungsversuch basierend auf Charisma und Zufall aus.
     *
     * @return true, wenn die Verhandlung gelingt, sonst false
     */
    public boolean negotiate() {
        double value = this.charismaPoints * 4.2;
        if (value <= 23) return false;
        java.util.Random rnd = new java.util.Random();
        int roll = rnd.nextInt(100);
        if (roll < 20) return false;
        return true;
    }
}

