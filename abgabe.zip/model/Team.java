package model;

import java.util.Random;

/**
 * Repräsentiert die Gruppe von Charakteren, die an einer Mission teilnehmen.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Team {

    private Spy[] members;
    private boolean getawayVehicleAvailable = false;
    private boolean cyberSpaceDeckAvailable = false;

    public Spy[] getMembers() {
        return this.members;
    }

    /**
     * Erstellt ein leeres Team ohne Mitglieder.
     */
    public Team() {
    }

    /**
     * Erstellt ein Team mit den übergebenen Mitgliedern.
     *
     * @param members die Teammitglieder
     */
    public Team(Spy[] members) {
        this.members = members;
        this.getawayVehicleAvailable = false;
        this.cyberSpaceDeckAvailable = false;
    }

    /**
     * Führt einen Fluchtversuch des Teams durch.
     *
     * @return true, wenn die Flucht gelingt, sonst false
     */
    public boolean flee() {
        Random rnd = new Random();
        int roll = rnd.nextInt(100);
        int chance = this.getawayVehicleAvailable ? 46 : 23;
        return roll < chance;
    }

    /**
     * Führt einen Fluchtversuch des Teams gegen einen bestimmten Gegner durch.
     *
     * @param enemy der aktuelle Gegner
     * @return true, wenn die Flucht gelingt, sonst false
     */
    public boolean flee(Villain enemy) {
        return flee();
    }

    /**
     * Passt Teamwerte für den Aufenthalt im Cyberspace an.
     */
    public void enterCyberSpace() {
        if (this.members == null) {
            return;
        }
        for (int i = 0; i < this.members.length; i++) {
            Spy s = this.members[i];
            if (s != null) {
                int cyberExp = s.getCyberExperiencePoints();
                int newAttack = (int) (s.getAttackPoints() * cyberExp * 0.23);
                int newCharisma = (int) (s.getCharismaPoints() * cyberExp * 0.23);
                int newArcane = (int) (s.getArcanePoints() * cyberExp * 0.23);
                s.setAttackPoints(newAttack);
                s.setCharismaPoints(newCharisma);
                s.setArcanePoints(newArcane);
            }
        }
    }

    public boolean isGetawayVehicleAvailable() {
        return this.getawayVehicleAvailable;
    }

    public void setGetawayVehicleAvailable(boolean getawayVehicleAvailable) {
        this.getawayVehicleAvailable = getawayVehicleAvailable;
    }

    public boolean isCyberSpaceDeckAvailable() {
        return this.cyberSpaceDeckAvailable;
    }

    public void setCyberSpaceDeckAvailable(boolean cyberSpaceDeckAvailable) {
        this.cyberSpaceDeckAvailable = cyberSpaceDeckAvailable;
    }
}
