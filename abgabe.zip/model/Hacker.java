package model;

/**
 * Ein spezialisierter Spion mit Hackerfähigkeiten.
 * Der Hacker startet mit 42 Lebenspunkten und zusätzlicher Cyber-Erfahrung.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Hacker extends Spy {

    /**
     * Erstellt einen Hacker mit vorgegebenem Namen und Beschreibung.
     * Die Lebenspunkte werden auf 42 gesetzt und die Cyber-Erfahrung zufällig erhöht.
     *
     * @param name der Name des Hackers
     * @param description die Beschreibung des Hackers
     */
    public Hacker(String name, String description) {
        super(name, description);
        this.setHealthPoints(42);
        this.setMaxHealthPoints(this.getHealthPoints());
        int bonusCyber = java.util.concurrent.ThreadLocalRandom.current().nextInt(5, 14);
        this.setCyberExperiencePoints(4 + bonusCyber);
    }
}
