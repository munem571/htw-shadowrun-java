package model;

/**
 * Ein spezieller großer Gegner (Giga), der von Villain erbt.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Giga extends Villain {

    private boolean boss = true;

    /**
     * Erstellt einen Giga-Gegner mit den angegebenen Grundwerten.
     *
     * @param name der Name des Gegners
     * @param description die Beschreibung des Gegners
     * @param healthPoints die Lebenspunkte des Gegners
     * @param attackPoints die Angriffspunkte des Gegners
     */
    public Giga(String name, String description, int healthPoints, int attackPoints) {
        super(name, description, healthPoints, attackPoints);
    }

    /**
     * Gibt an, ob dieser Gegner als Boss gilt.
     *
     * @return true, wenn es sich um einen Boss handelt
     */
    public boolean isBoss() {
        return this.boss;
    }
}
