package model;

/**
 * Basisklasse für Gegner (Villains) im Spiel.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Villain {

    private String name;
    private String description;
    private int healthPoints;
    private int attackPoints;

    /**
     * Erstellt einen Gegner mit Grundwerten.
     *
     * @param name der Name des Gegners
     * @param description die Beschreibung des Gegners
     * @param healthPoints die Start-Lebenspunkte
     * @param attackPoints die Angriffspunkte
     */
    public Villain(String name, String description, int healthPoints, int attackPoints) {
        this.name = name;
        this.description = description;
        this.healthPoints = healthPoints;
        this.attackPoints = attackPoints;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public int getAttackPoints() {
        return attackPoints;
    }

    public void setHealthPoints(int hp) {
        this.healthPoints = hp;
    }

    /**
     * Verarbeitet eingehenden Schaden und reduziert die Lebenspunkte.
     *
     * @param amount der erlittene Schaden
     */
    public void takeDamage(int amount) {
        if (amount <= 0) return;
        this.healthPoints -= amount;
        if (this.healthPoints < 0) this.healthPoints = 0;
        System.out.println("Gegner hat " + amount + " Schaden erlitten. Verbleibende LP: " + this.healthPoints);
    }

    /**
     * Prüft, ob der Gegner besiegt wurde.
     *
     * @return true, wenn keine Lebenspunkte mehr vorhanden sind
     */
    public boolean isDefeated() {
        return this.healthPoints <= 0;
    }
}
