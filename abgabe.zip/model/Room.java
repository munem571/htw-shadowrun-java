package model;

/**
 * Repräsentiert einen Raum oder Ort, der während der Mission verwendet wird.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Room {

}
