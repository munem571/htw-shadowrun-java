package model;

import java.util.Random;

/**
 * Eine spezielle Spy-Unterklasse für einen Zauberer.
 * Der Sorcerer startet mit zufälligen Lebenspunkten und arkanen Kräften.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Sorcerer extends Spy {

    /**
     * Erstellt einen Sorcerer mit vorgegebenem Namen und Beschreibung.
     * Die Lebenspunkte werden zufällig zwischen 15 und 50 gesetzt
     * und die Arkanpunkte zufällig zwischen 8 und 42.
     *
     * @param name der Name des Sorcerer
     * @param description die Beschreibung des Sorcerer
     */
    public Sorcerer(String name, String description) {
        super(name, description);
        Random random = new Random();
        setHealthPoints(random.nextInt(36) + 15);
        setMaxHealthPoints(this.getHealthPoints());
        setArcanePoints(random.nextInt(35) + 8);
    }
}