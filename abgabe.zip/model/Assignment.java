package model;

/**
 * Repräsentiert eine Mission oder Aufgabe, die das Team akzeptieren kann.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Assignment {
    private String description;
    private boolean cyber;
    private boolean completed = false;
    private int experienceNeeded;

    /**
     * Erstellt eine neue Aufgabe mit den angegebenen Eigenschaften.
     *
     * @param description die Missionsbeschreibung
     * @param cyber gibt an, ob es sich um eine Cyber-Mission handelt
     * @param experienceNeeded benötigte Erfahrungspunkte
     */
    public Assignment(String description, boolean cyber, int experienceNeeded) {
        this.description = description;
        this.cyber = cyber;
        this.experienceNeeded = experienceNeeded;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isCyber() {
        return cyber;
    }

    public void setCyber(boolean cyber) {
        this.cyber = cyber;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public int getExperienceNeeded() {
        return experienceNeeded;
    }

    public void setExperienceNeeded(int experienceNeeded) {
        this.experienceNeeded = experienceNeeded;
    }
}
