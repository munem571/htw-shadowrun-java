package model;

import java.util.Random;

/**
 * Eine spezielle Spy-Unterklasse für einen Negotiator.
 * Der Negotiator startet mit 50 Lebenspunkten und verbessert seine Charisma-Punkte.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Negotiator extends Spy {

    /**
     * Erstellt einen Negotiator mit vorgegebenem Namen und Beschreibung.
     * Die Lebenspunkte werden auf 50 gesetzt und die Charisma-Punkte zufällig erhöht.
     *
     * @param name der Name des Negotiator
     * @param description die Beschreibung des Negotiator
     */
    public Negotiator(String name, String description) {
        super(name, description);
        setHealthPoints(50);
        setMaxHealthPoints(this.getHealthPoints());
        Random random = new Random();
        int bonusCharisma = random.nextInt(6) + 5;
        setCharismaPoints(getCharismaPoints() + bonusCharisma);
    }
}