package model;

/**
 * Ein spezieller Gegner (Decker), der von Villain erbt.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class Decker extends Villain {

    private boolean cyberspaceDeck = true;

    /**
     * Erstellt einen Decker mit Name, Beschreibung, Lebenspunkten und Angriffspunkten.
     *
     * @param name der Name des Deckers
     * @param description die Beschreibung des Deckers
     * @param healthPoints die Lebenspunkte des Deckers
     * @param attackPoints die Angriffspunkte des Deckers
     */
    public Decker(String name, String description, int healthPoints, int attackPoints) {
        super(name, description, healthPoints, attackPoints);
    }

    /**
     * Gibt an, ob der Decker ein Cyberspace-Deck besitzt.
     *
     * @return true, wenn ein Deck vorhanden ist
     */
    public boolean hasCyberspaceDeck() {
        return this.cyberspaceDeck;
    }
}
