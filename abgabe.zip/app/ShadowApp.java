package app;

import java.util.Scanner;

/**
 * Klasse für den Hauptprogrammablauf des Spiels.
 * Diese Klasse zeigt das Hauptmenü an, liest Benutzerangaben und startet das Spiel.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class ShadowApp {
    /** Aktuelle Spielinstanz. */
    private ShadowRun game;

    /** Gemeinsamer Scanner für alle Konsoleneingaben. */
    private final Scanner inputScanner = new Scanner(System.in);

    /** Maximale Anzahl an Runden im Spielmenü. */
    private static final int MAX_ROUNDS = 30;

    /** Flag, das angibt, ob die Anwendung noch läuft. */
    private boolean gameRunning = true;

    /**
     * Startet das Spiel und initialisiert die Spielumgebung.
     *
     * @param args Programmargumente (werden nicht verwendet)
     */
    public static void main(String[] args) {
        ShadowApp app = new ShadowApp();
        app.printWelcome();

        while (app.gameRunning) {
            app.showMainMenu();
            String choice = app.readUserInput();
            app.handleUserInput(choice);
            System.out.println("========================");
        }
        app.inputScanner.close();
    }

    /**
     * Gibt den Begrüßungstext auf der Konsole aus.
     */
    private void printWelcome() {
        System.out.println("=== WILLKOMMEN ZU SHADOWRUN 2042 ===");
    }

    /**
     * Zeigt die Optionen des Hauptmenüs an.
     */
    private void showMainMenu() {
        System.out.println("Du befindest dich im Hauptmenü");
        System.out.println("Was möchstest du als nächstes tun?");
        System.out.println("(1) Spiel starten");
        if (isGameRunning()) {
            System.out.println("(2) Spiel fortsetzen");
        }
        System.out.println("(3) Programm beenden");
        System.out.println("");
        System.out.println("Wähle bitte eine Option: ");
    }

    /**
     * Liest die Eingabe des Benutzers von der Konsole.
     *
     * @return die eingegebene Benutzereingabe
     */
    private String readUserInput() {
        String userInput = inputScanner.nextLine();
        System.out.println("Du hast '" + userInput + "' eingetippt.");
        return userInput;
    }

    /**
     * Zeigt das Spielmenü mit aktuellem Rundenstatus an.
     */
    private void showGameMenu() {
        System.out.println("=== Spielmenü (Runde " + game.getCurrentRound() + "/" + MAX_ROUNDS + ") ===");
        System.out.println("(1) Status anzeigen");
        System.out.println("(2) Team heilen");
        System.out.println("(3) Gelände erkunden");
        System.out.println("(4) Cyberspace erkunden");
        System.out.println("(5) Spiel verlassen");
    }

    /**
     * Verarbeitet die Benutzerauswahl aus dem Hauptmenü.
     *
     * @param input die gewählte Menüoption
     */
    private void handleUserInput(String input) {
        switch (input) {
            case "1":
                this.startGame();
                break;
            case "2":
                if (this.game != null && !this.game.isGameFinished()) {
                    this.resumeGame();
                } else {
                    System.out.println("Kein laufendes Spiel vorhanden!");
                }
                break;
            case "3":
                this.exitGame();
                break;
            default:
                System.out.println("Ungültige Angabe. Wähle bitte eine gültige Option.");
                break;
        }
    }

    /**
     * Startet ein neues Spiel und setzt die Spielumgebung auf.
     */
    private void startGame() {
        model.Spy[] teamMembers = new model.Spy[5];

        teamMembers[0] = new model.StreetSamurai("Prof. Majuntke", "Die gnadenlose Anführerin mit dem Katana.");
        teamMembers[1] = new model.Negotiator("Thomas Poeser", "Meister der Diplomatie und Notengebung.");
        teamMembers[2] = new model.Hacker("Selim Gnaoui", "Knackt jede Firewall in Lichtgeschwindigkeit.");
        teamMembers[3] = new model.Sorcerer("Reni Safitri", "Der Combat-Medic des Teams. Nutzt Heilmagie, wenn die Lage eskaliert.");
        System.out.println("Gib den Namen deines fünften Charakters ein:");
        String customName = inputScanner.nextLine();
        System.out.println("Gib die Beschreibung deines Charakters ein:");
        String customDescription = inputScanner.nextLine();
        System.out.println("Wähle die Klasse: (1) Hacker, (2) Negotiator, (3) Street Samurai");
        String selectedClass = inputScanner.nextLine();
        System.out.println("Du hast '" + selectedClass + "' eingetippt.");

        if ("1".equals(selectedClass)) {
            teamMembers[4] = new model.Hacker(customName, customDescription);
        } else if ("2".equals(selectedClass)) {
            teamMembers[4] = new model.Negotiator(customName, customDescription);
        } else {
            teamMembers[4] = new model.StreetSamurai(customName, customDescription);
        }

        model.Team newTeam = new model.Team(teamMembers);
        this.game = new ShadowRun();
        this.game.setTeam(newTeam);

        resumeGame();
    }

    /**
     * Setzt das Spiel fort und ruft die Spielschleife auf.
     */
    private void resumeGame() {
        if (this.game == null) {
            System.out.println("Kein Spiel gestartet. Bitte wähle zuerst 'Spiel starten'.");
            return;
        }
        this.game.setGameRunning(true);
        if (this.game.getCurrentRound() == 0) {
            this.game.run();
        }
        while (this.game.isGameRunning() && !this.game.isGameFinished()) {
            showGameMenu();
            String input = readUserInput();
            handleGameMenuInput(input);
            if (game.getCurrentRound() >= MAX_ROUNDS) {
                game.setGameFinished(true);
                System.out.println("30 Runden sind um – die Mission ist gescheitert. Spiel verloren!");
            } else if (areAllSpiesDead()) {
                game.setGameFinished(true);
                System.out.println("Alle Spione sind tot – die Mission ist gescheitert. Spiel verloren!");
            }
        }
    }

    /**
     * Verarbeitet die Auswahl des Spielmenüs und leitet sie an das Spiel weiter.
     *
     * @param input die gewählte Menüoption
     */
    private void handleGameMenuInput(String input) {
        if (this.game == null) {
            System.out.println("Kein Spiel gestartet. Bitte wähle zuerst 'Spiel starten'.");
            return;
        }
        switch (input) {
            case "1":
                this.game.showStatus();
                break;
            case "2":
                this.game.healTeam();
                break;
            case "3":
                this.game.exploreTerrain();
                break;
            case "4":
                this.game.exploreCyberspace();
                break;
            case "5":
                this.game.setGameRunning(false);
                System.out.println("Spiel pausiert. Du bist zurück im Hauptmenü.");
                break;
            default:
                System.out.println("Ungültige Angabe. Wähle bitte eine gültige Option.");
                break;
        }
    }

    /**
     * Überprüft, ob alle Spione im aktuellen Team eliminiert wurden.
     *
     * @return true, wenn alle Spione tot sind, sonst false
     */
    private boolean areAllSpiesDead() {
        if (game == null || game.getTeam() == null) {
            return false;
        }
        model.Spy[] members = game.getTeam().getMembers();
        if (members == null || members.length == 0) {
            return false;
        }
        for (model.Spy s : members) {
            if (s != null && s.isAlive()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Beendet das Programm und führt Aufräumarbeiten durch.
     */
    private void exitGame() {
        System.out.println("Programm wird beendet.");
        this.gameRunning = false;
    }

    /**
     * Prüft, ob ein Spiel aktuell gestartet wurde.
     *
     * @return true, wenn ein Spiel existiert, sonst false
     */
    private boolean isGameRunning() {
        return game != null;
    }

}