package app;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import model.Assignment;
import model.Team;

/**
 * Repräsentiert den Kernzustand und die Spiellogik von ShadowRun.
 *
 * @author Kabillan Jeyaragawan
 * @author Mohammed Munem Hossain
 */
public class ShadowRun {
    /** Maximale Anzahl an Runden im Spiel. */
    private static final int MAX_ROUNDS = 30; 

    /** Aktuelle Spielrunde. */
    private int currentRound = 0; 

    /** Mögliche Aufgaben, die dem Team angeboten werden. */
    private final Assignment[] possibleAssignments = new Assignment[5];

    /** Das Team, das an der Mission teilnimmt. */
    private Team team;

    /** Flag, das angibt, ob die Spielschleife aktiv ist. */
    private boolean gameRunning = true;

    /** Flag, das anzeigt, ob das Spiel beendet wurde. */
    private boolean gameFinished = false;

    /** Flag, das anzeigt, ob das Team in dieser Runde bereits geheilt wurde. */
    private boolean healedThisRound = false;

    /**
     * Erstellt eine neue ShadowRun-Spielinstanz und befüllt die möglichen Missionen.
     */
    public ShadowRun() {
        possibleAssignments[0] = new Assignment("Datenklau in der Konzernzentrale", true, 120); 
        possibleAssignments[1] = new Assignment("Geheimdokumente aus dem Forschungslabor stehlen", true, 100);
        possibleAssignments[2] = new Assignment("Auftragskiller in der Unterstadt aufspüren", false, 90);
        possibleAssignments[3] = new Assignment("Schmuggelroute durch die Kanalisation sichern", false, 80);
        possibleAssignments[4] = new Assignment("Sabotageauftrag bei einer Cyberwaffen-fabrik", true, 150);
    }

    /**
     * Liefert eine zufällige Aufgabe für das Spiel.
     *
     * @return eine zufällige Assignment-Instanz
     */
    public Assignment getAssignment(){ 
        int index = ThreadLocalRandom.current().nextInt(possibleAssignments.length); 
        return possibleAssignments[index];
    }

    /**
     * Führt die Hauptspiellogik aus.
     */
    public void run() {
        Assignment currentAssignment = getAssignment(); 
        System.out.println("Neue Mission: " + currentAssignment.getDescription()); 
        System.out.println("Cyber-Mission: " + currentAssignment.isCyber()); 
        System.out.println("Erforderliche Erfahrung: " + currentAssignment.getExperienceNeeded());        
        System.out.println();
    }

    /**
     * Zeigt den aktuellen Status aller Teammitglieder sowie verfügbare Ressourcen an.
     */
    public void showStatus() {
        if (this.team == null || this.team.getMembers() == null) { 
            System.out.println("Kein Team vorhanden.");
            return;
        }

        System.out.println("=== Teamstatus ==="); 
        for (model.Spy member : this.team.getMembers()) { 
            if (member == null) {
                continue;
            }
            System.out.println("Name: " + member.getName()); 
            System.out.println("Klasse: " + member.getClass().getSimpleName()); 
            System.out.println("HealthPoints: " + member.getHealthPoints()); 
            System.out.println("---------------------------"); 
        }
        System.out.println("Getaway Vehicle verfügbar: " + this.team.isGetawayVehicleAvailable()); 
        System.out.println("Cyberspace Deck verfügbar: " + this.team.isCyberSpaceDeckAvailable()); 
    }

    /**
     * Liefert die aktuelle Runde des Spiels.
     *
     * @return die aktuelle Rundenzahl
     */
    public int getCurrentRound() {
        return currentRound;
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    /**
     * Setzt den laufenden Zustand des Spiels.
     *
     * @param gameRunning true, wenn das Spiel laufen soll
     */
    public void setGameRunning(boolean gameRunning) { 
        this.gameRunning = gameRunning;
    }

    /**
     * Gibt zurück, ob das Spiel beendet ist.
     *
     * @return true, wenn das Spiel abgeschlossen ist
     */
    public boolean isGameFinished() {
        return gameFinished;
    }

    /**
     * Setzt den Abschlusszustand des Spiels.
     *
     * @param gameFinished true, wenn das Spiel als beendet markiert werden soll
     */
    public void setGameFinished(boolean gameFinished) {
        this.gameFinished = gameFinished;
    }

    public void setTeam(Team team) { 
        this.team = team;
    }

    public Team getTeam() { 
        return this.team;
    }

    /**
     * Lässt den Zauberer im Team alle lebenden Mitglieder um 5 HP heilen.
     * Funktioniert nur einmal pro Runde und nur wenn ein Sorcerer im Team ist.
     */
    public void healTeam() {
        if (healedThisRound) {
            System.out.println("In dieser Runde wurde bereits geheilt!");
            return;
        }
        if (this.team == null) { 
            System.out.println("Kein Team vorhanden."); 
            return; 
        }
        model.Spy[] members = this.team.getMembers(); 
        if (members == null || members.length == 0) { 
            System.out.println("Kein Team vorhanden."); 
            return;
        }

        model.Sorcerer sorcerer = null; 
        for (model.Spy s : members) {
            if (s instanceof model.Sorcerer) { 
                sorcerer = (model.Sorcerer) s; 
                break;
            }
        }

        if (sorcerer == null) { 
            System.out.println("Kein Magier im Team!"); 
            return;
        }

        int roll = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 9); 
        int arcane = sorcerer.getArcanePoints();
        int power = arcane * roll; 

        if (power > 50) { // Überprüft, ob die berechnete Heilungsstärke größer als 50 ist
            for (model.Spy s : members) {
                if (s == null) continue; // Überspringt null-Mitglieder im Team
                int current = s.getHealthPoints();// Holt die aktuellen Lebenspunkte des Teammitglieds
                int maxHp = s.getMaxHealthPoints();

                int healed = Math.min(current + 5, maxHp); // nimmt die aktuellen Lebenspunkte und fügt 5 hinzu, überschreitet jedoch nicht das maximale HP-Limit
                s.setHealthPoints(healed);
            }
            System.out.println("Die Heilung ist gelungen! Alle Teammitglieder wurden um 5 HP geheilt.\n");
        } else {
            System.out.println("Die Heilung ist fehlgeschlagen.");
        }
        healedThisRound = true;
    }

    /**
     * Erkundet das Gelände in der aktuellen Runde und erhöht den Rundenzähler.
     * Mit 40% Wahrscheinlichkeit passiert nichts, sonst taucht ein zufälliger Gegner auf.
     */
    public void exploreTerrain() {
        currentRound++;
        healedThisRound = false;
        int roll = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 101); // 1..100
        if (roll <= 40) {
            System.out.println("Das Gelände ist ruhig. Nichts passiert.");
            return;
        }

        System.out.println("Ihr trefft auf einen Gegner!");

        int enemyRoll = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 101); // 1..100
        if (enemyRoll <= 60) { // 60%: Standard-Gegner
            model.Villain enemy = new model.Villain(
                "Konzern-Wache",
                "Ein einfacher Sicherheitsbeamter",
                30,
                5
            );
            System.out.println("Gegner entdeckt: " + enemy.getName() + " - " + enemy.getDescription());
            handleEncounter(enemy, false);
        } else if (enemyRoll <= 80) { // 20%: Driver 
            model.Driver driver = new model.Driver(
                "Straßenracer",
                "Ein gefährlicher Fahrer im Dienst des Konzerns",
                50,
                8
            );
            System.out.println("Driver entdeckt: " + driver.getName() + " - " + driver.getDescription());
            handleEncounter(driver, false);
        } else if (enemyRoll <= 90) { // 10%: Decker 
            model.Decker decker = new model.Decker(
                "Netz-Phantom",
                "Ein Hacker, der im Cyberspace ebenso tödlich ist wie in der realen Welt",
                40,
                10
            );
            System.out.println("Decker entdeckt: " + decker.getName() + " - " + decker.getDescription());
            handleEncounter(decker, false);
        } else { // 91-100 -> 10%: Endgegner
            model.Giga boss = new model.Giga(
                "Megacorp-Mech",
                "Ein riesiger Kampfroboter",
                100,
                15
            );
            System.out.println("Endgegner entdeckt: " + boss.getName() + " - " + boss.getDescription());
            handleEncounter(boss, false);
        }
        checkGameEnd();
    }

    /**
     * Erkundet den Cyberspace in der aktuellen Runde und erhöht den Rundenzähler.
     * Die Wahrscheinlichkeit eines Gegners hängt vom höchsten Cyber-Erfahrungswert im Team ab.
     */
    public void exploreCyberspace() {
        currentRound++;
        healedThisRound = false;
        if (this.team == null) {
            System.out.println("Kein Team vorhanden.");
            return;
        }
        model.Spy[] members = this.team.getMembers(); // Holt die Mitglieder des Teams
        if (members == null || members.length == 0) { 
            System.out.println("Kein Team vorhanden.");
            return;
        }

        int highest = 0; // Speichert die höchsten Cyber-Erlebnispunkte
        for (model.Spy s : members) { // Iteriert über die Mitglieder des Teams
            if (s == null) continue;
            int cyber = s.getCyberExperiencePoints(); // Holt die Cyber-Erlebnispunkte des aktuellen Mitglieds
            if (cyber > highest) highest = cyber;// Aktualisiert die höchsten Cyber-Erlebnispunkte, wenn das aktuelle Mitglied mehr hat
        }

       
        int enemyProbability = 100 - highest; // Berechnet die Wahrscheinlichkeit für einen Gegner (100 - höchster Cyber-Wert)
        
        // Würfeln, ob ein Gegner auftaucht (Zahl von 1 bis 100)
        int spawnRoll = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 101);
        
        if (spawnRoll <= enemyProbability) {
            // Ein Gegner hat das Team entdeckt!
            System.out.println("Ein Cyberspace-Gegner hat euch entdeckt!");
            
            
            int typeRoll = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 101);

            if (typeRoll <= 50) { // 50% Chance
                model.Villain enemy = new model.Villain(
                    "Konzern-Sucher",
                    "Ein digitaler Späher im Dienst des Megakonzerns",
                    25,
                    5
                );
                System.out.println("Cyberspace-Gegner entdeckt: " + enemy.getName() + " - " + enemy.getDescription());
                handleEncounter(enemy, true);
            } else if (typeRoll <= 90) { // 40% Chance (50 + 40 = 90)
                model.Decker decker = new model.Decker(
                    "Feindlicher Hacker",
                    "Ein skrupelloser Decker, der fremde Systeme zerstört",
                    40,
                    10
                );
                System.out.println("Cyberspace-Gegner entdeckt: " + decker.getName() + " - " + decker.getDescription());
                handleEncounter(decker, true);
            } else { // Die restlichen 10% Chance (91-100)
                model.Giga boss = new model.Giga(
                    "Konzern-KI",
                    "Eine mächtige künstliche Intelligenz, die den Cyberspace kontrolliert",
                    100,
                    20
                );
                System.out.println("Cyberspace-Endgegner entdeckt: " + boss.getName() + " - " + boss.getDescription());
                handleEncounter(boss, true);
            }
        } else {
            // Glück gehabt! Der Cyber-Erfahrungswert war hoch genug, um unentdeckt zu bleiben
            System.out.println("Der Cyberspace ist ruhig. Eure Cyber-Erfahrung hat euch unbemerkt durchgeschleust!");
        }
        checkGameEnd();
    }

    /**
     * Zeigt das Begegnungsmenü und behandelt die Wahl des Spielers.
     *
     * @param enemy   der Bösewicht, dem das Team begegnet
     * @param isCyber gibt an, ob die Begegnung im Cyberspace stattfindet
    */
    public void handleEncounter(model.Villain enemy, boolean isCyber) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Begegnung! ===");
        System.out.println("Du triffst auf: " + enemy.getName() + " – " + enemy.getDescription());
        String choice = "";
        while (true) {
            System.out.println("Was möchtest du tun?");
            System.out.println("a) Kämpfen");
            System.out.println("b) Fliehen");
            System.out.println("c) Belabern");
            System.out.print("Deine Wahl: ");
            choice = scanner.nextLine();

            if (choice.equals("a") || choice.equals("A")
                    || choice.equals("b") || choice.equals("B")
                    || choice.equals("c") || choice.equals("C")) {
                break;
            }

            System.out.println("Ungültige Eingabe. Bitte wähle eine der vorhandenen Optionen.");
        }

        if (choice.equals("a") || choice.equals("A")) {
            startCombat(enemy);

        } else if (choice.equals("b") || choice.equals("B")) {
            boolean fled = this.team.flee(enemy);
            if (fled) {
                System.out.println("Flucht erfolgreich! Das Team ist entkommen.");
            } else {
                System.out.println("Flucht fehlgeschlagen! Das Team muss sich dem Kampf stellen.");
                startCombat(enemy);
            }

        } else if (choice.equals("c") || choice.equals("C")) {
            model.Spy spy = selectLivingSpy(scanner);
            if (spy == null) {
                System.out.println("Das gesamte Team wurde ausgelöscht! Das Spiel ist vorbei.");
                this.gameRunning = false;
                return;
            }
            boolean success = spy.negotiate();
            if (success) {
                System.out.println("Verhandlung erfolgreich! Der Gegner zieht ab.");
            } else {
                System.out.println("Belabern fehlgeschlagen!");
                boolean fled = this.team.flee(enemy);
                if (fled) {
                    System.out.println("Flucht erfolgreich! Das Team ist entkommen.");
                } else {
                    System.out.println("Auch die Flucht ist fehlgeschlagen! Kampf beginnt.");
                    startCombat(enemy);
                }
            }
        }
    }

    /**
     * Führt einen rundenbasierten Kampf zwischen dem Team und dem Bösewicht durch.
     *
     * @param enemy der Bösewicht, gegen den gekämpft wird
    */
    private void startCombat(model.Villain enemy) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n=== Kampf beginnt! ===");

        while (!enemy.isDefeated() && isTeamAlive()) {
            System.out.println("\n" + enemy.getName() + " hat noch " + enemy.getHealthPoints() + " LP.");

            model.Spy spy = selectLivingSpy(scanner);
            if (spy == null) {
                System.out.println("Kein lebender Spion mehr verfügbar!");
                break;
            }

            // Spion greift den Gegner an
            int damage = spy.attack();
            enemy.takeDamage(damage);
            System.out.println(spy.getName() + " greift an und verursacht " + damage + " Schaden.");

            // Gegner greift zurück, wenn er noch lebt
            if (!enemy.isDefeated()) {
                int enemyDamage = enemy.getAttackPoints();
                spy.takeDamage(enemyDamage);
                System.out.println(enemy.getName() + " greift zurück und verursacht "
                        + enemyDamage + " Schaden an " + spy.getName() + ".");
                if (!spy.isAlive()) {
                    System.out.println(spy.getName() + " wurde ausgeschaltet!");
                }
            }
        }

        if (enemy.isDefeated()) {
            System.out.println("\nGegner " + enemy.getName() + " wurde besiegt!");

            if (enemy instanceof model.Driver && !this.team.isGetawayVehicleAvailable()) {
                this.team.setGetawayVehicleAvailable(true);
                System.out.println("Ein Fluchtfahrzeug wurde erbeutet!");

            } else if (enemy instanceof model.Decker && !this.team.isCyberSpaceDeckAvailable()) {
                this.team.setCyberSpaceDeckAvailable(true);
                System.out.println("Ein Cyberspace-Deck wurde erbeutet!");

            } else if (enemy instanceof model.Giga) {
                int totalExp = 0;
                for (model.Spy s : this.team.getMembers()) {
                    if (s != null) {
                        totalExp += s.getCyberExperiencePoints();
                    }
                }
                if (totalExp >= 20) {
                    System.out.println("Das Spiel ist gewonnen! Der Endgegner wurde besiegt!");
                    this.gameRunning = false;
                    this.gameFinished = true;
                } else {
                    System.out.println("Endgegner besiegt, aber dem Team fehlt noch Erfahrung ("
                            + totalExp + " / benötigt: 20).");
                }
            }

        } else {
            System.out.println("\nDas gesamte Team wurde besiegt. Game Over!");
            this.gameRunning = false;
            this.gameFinished = true;
        }
    }

    /**
     * Lässt den Spieler einen lebenden Spion per Index auswählen.
     *
     * @param scanner der Scanner für die Konsoleneingabe
     * @return der ausgewählte Spion oder null bei ungültiger Eingabe
    */
    private model.Spy selectLivingSpy(Scanner scanner) {
        model.Spy[] members = this.team.getMembers();
        if (members == null) {
            return null;
        }

        while (true) {
            System.out.println("Wähle einen lebenden Spion:");
            for (int i = 0; i < members.length; i++) {
                if (members[i] != null && members[i].isAlive()) {
                    System.out.println(i + ") " + members[i].getName()
                            + " (HP: " + members[i].getHealthPoints() + ")");
                }
            }

            System.out.print("Index eingeben: ");

            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                System.out.println("Ungültige Auswahl.");
                continue;
            }

            int index = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Du hast '" + index + "' eingetippt.");

            if (index >= 0 && index < members.length
                    && members[index] != null && members[index].isAlive()) {
                return members[index];
            }

            System.out.println("Ungültige Auswahl.");
        }
    }

    /**
     * Prüft, ob noch mindestens ein Teammitglied am Leben ist.
     *
     * @return true, wenn mindestens ein Spion noch lebt
    */
    private boolean isTeamAlive() {
        if (this.team == null || this.team.getMembers() == null) {
            return false;
        }
        for (model.Spy s : this.team.getMembers()) {
            if (s != null && s.isAlive()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Überprüft am Ende jeder Runde, ob die Sieg- oder Niederlagebedingungen 
     * erfüllt sind (Rundenlimit oder Tod des Teams).
     */
    public void checkGameEnd() {
        // Wenn das Spiel durch den Sieg über den Endgegner schon beendet wurde
        if (this.gameFinished && !this.gameRunning) {
            return; // Dann müssen wir hier nichts mehr tun, die Siegesmeldung kam schon
        }

        // Überprüfe die Niederlage-Bedingung 1: 30 Runden vorbei
        if (this.currentRound >= MAX_ROUNDS) {
            System.out.println("\n=== NIEDERLAGE ===");
            System.out.println("Die Zeit ist abgelaufen! Ihr habt die 30 Runden überschritten, ohne den Auftrag zu erfüllen.");
            this.gameRunning = false;
            this.gameFinished = true;
        }
        // Überprüfe die Niederlage-Bedingung 2: Alle Spione tot
        else if (this.team != null && this.team.getMembers() != null) {
            boolean atLeastOneSpyAlive = false;
            for (model.Spy s : this.team.getMembers()) {
                if (s != null && s.isAlive()) {
                    atLeastOneSpyAlive = true;
                }
            }

            if (!atLeastOneSpyAlive) {
                System.out.println("\n=== NIEDERLAGE ===");
                System.out.println("Das gesamte Team wurde eliminiert! Die Mission ist gescheitert.");
                this.gameRunning = false;
                this.gameFinished = true;
            }
        }
    }
}